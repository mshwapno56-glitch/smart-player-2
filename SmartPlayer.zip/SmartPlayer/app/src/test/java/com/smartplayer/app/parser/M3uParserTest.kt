package com.smartplayer.app.parser

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.BufferedReader
import java.io.StringReader

class M3uParserTest {

    private fun parseAll(text: String, batchSize: Int = 1000): Pair<List<ParsedChannel>, Int> {
        val out = ArrayList<ParsedChannel>()
        var batches = 0
        runBlocking {
            M3uParser.parse(BufferedReader(StringReader(text)), batchSize) {
                out.addAll(it)
                batches++
            }
        }
        return out to batches
    }

    @Test
    fun parsesBasicEntry() {
        val (list, _) = parseAll(
            """
            #EXTM3U
            #EXTINF:-1 tvg-id="abc" tvg-logo="http://x/logo.png" group-title="News",BBC One
            http://host/live/1.m3u8
            """.trimIndent()
        )
        assertEquals(1, list.size)
        val c = list[0]
        assertEquals("BBC One", c.name)
        assertEquals("News", c.groupTitle)
        assertEquals("http://x/logo.png", c.logoUrl)
        assertEquals("abc", c.tvgId)
        assertEquals("http://host/live/1.m3u8", c.url)
    }

    @Test
    fun commaInsideQuotedAttributeDoesNotBreakName() {
        val (list, _) = parseAll(
            """
            #EXTINF:-1 group-title="News, World",Channel A
            http://host/a
            """.trimIndent()
        )
        assertEquals("Channel A", list[0].name)
        assertEquals("News, World", list[0].groupTitle)
    }

    @Test
    fun usesExtGrpWhenNoGroupTitle() {
        val (list, _) = parseAll(
            """
            #EXTINF:-1,Sports One
            #EXTGRP:Sports
            http://host/s1
            """.trimIndent()
        )
        assertEquals("Sports", list[0].groupTitle)
    }

    @Test
    fun skipsVlcOptAndBlankLinesAndHandlesCrlf() {
        val text = "#EXTM3U\r\n\r\n#EXTINF:-1,One\r\n#EXTVLCOPT:http-user-agent=x\r\nhttp://host/1\r\n"
        val (list, _) = parseAll(text)
        assertEquals(1, list.size)
        assertEquals("http://host/1", list[0].url)
        assertNull(list[0].logoUrl)
    }

    @Test
    fun urlWithoutExtInfIsIgnored() {
        val (list, _) = parseAll("#EXTM3U\nhttp://orphan/url\n")
        assertEquals(0, list.size)
    }

    @Test
    fun splitsIntoBatches() {
        val sb = StringBuilder("#EXTM3U\n")
        for (i in 1..2500) sb.append("#EXTINF:-1,Ch $i\nhttp://h/$i\n")
        val (list, batches) = parseAll(sb.toString(), batchSize = 1000)
        assertEquals(2500, list.size)
        assertEquals(3, batches)
    }

    @Test
    fun parsesLargePlaylist() {
        val sb = StringBuilder("#EXTM3U\n")
        for (i in 1..100_000) sb.append("#EXTINF:-1 group-title=\"G${i % 50}\",Ch $i\nhttp://h/$i\n")
        val (list, _) = parseAll(sb.toString())
        assertEquals(100_000, list.size)
        assertEquals("Ch 100000", list.last().name)
    }
}
