package com.smartplayer.app

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.smartplayer.app.data.ChannelEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Finds the channel before or after another one, in the list the user is looking at. */
interface ChannelNavigator {
    suspend fun neighbour(current: ChannelEntity, forward: Boolean): ChannelEntity?
}

/**
 * The video, living inside the main screen. It has three states:
 *
 * - [Mode.NONE]: nothing is playing.
 * - [Mode.MINI]: a small floating video over the channel list. It can be dragged, a tap
 *   makes it fullscreen, and it turns fullscreen by itself after a few seconds without
 *   any touch on the screen (see [AppPrefs.autoFullscreenSeconds]).
 * - [Mode.FULL]: the whole screen. Swipe up/down on the left half = brightness, right
 *   half = volume. Back returns to [Mode.MINI]; Back again closes the video.
 *
 * One ExoPlayer serves all three states, so switching never restarts the stream.
 */
class PlayerHost(
    private val activity: Activity,
    private val root: FrameLayout,
    private val scope: CoroutineScope,
    private val navigator: ChannelNavigator
) {
    enum class Mode { NONE, MINI, FULL }

    companion object {
        private const val MAX_NETWORK_RETRIES = 3
    }

    var mode = Mode.NONE
        private set

    val isActive: Boolean get() = mode != Mode.NONE

    private val handler = Handler(Looper.getMainLooper())
    private val isTv = DeviceUtil.isTv(activity)
    private val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val touchSlop = ViewConfiguration.get(activity).scaledTouchSlop

    private fun dp(value: Int) = (value * activity.resources.displayMetrics.density).toInt()

    // geometry of the small floating video
    private val margin = dp(12)
    private val miniWidth = if (isTv) dp(360) else dp(220)
    private val miniHeight = miniWidth * 9 / 16
    private var miniTx = 0f
    private var miniTy = 0f

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var host: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var closeButton: ImageButton
    private lateinit var indicator: TextView
    private lateinit var errorText: TextView
    private lateinit var gestureDetector: GestureDetector

    private var channel: ChannelEntity? = null
    private var triedHls = false
    private var networkRetries = 0

    // brightness / volume swipe state: 0 = none, 1 = brightness, 2 = volume
    private var gestureMode = 0
    private var brightness = 0.5f
    private var volumeLevel = 0f

    // dragging the small video
    private var downRawX = 0f
    private var downRawY = 0f
    private var startTx = 0f
    private var startTy = 0f
    private var dragging = false

    /** True while a dialog is open, so the video does not turn fullscreen behind it. */
    private var modalOpen = false

    /** True while the app is shown as the system Picture-in-Picture window. */
    private var inPip = false

    private val autoFullscreen = Runnable {
        if (mode == Mode.MINI && !modalOpen) setMode(Mode.FULL)
    }
    private val hideIndicator = Runnable { indicator.visibility = View.GONE }

    init {
        buildPlayer()
        buildViews()
        root.addView(
            host,
            FrameLayout.LayoutParams(miniWidth, miniHeight, Gravity.BOTTOM or Gravity.END)
        )
        host.visibility = View.GONE
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (mode == Mode.MINI) clampMini()
        }
    }

    // ---- public controls ----

    /** Starts [channel]. From nothing it opens the small floating video. */
    fun play(channel: ChannelEntity) {
        startChannel(channel)
        when (mode) {
            Mode.NONE -> setMode(Mode.MINI)
            Mode.MINI -> scheduleAutoFullscreen()
            Mode.FULL -> Unit
        }
    }

    fun closePlayer() = setMode(Mode.NONE)

    /** Call on any touch, key press or scroll: the fullscreen timer starts over. */
    fun onUserActivity() {
        if (mode == Mode.MINI) scheduleAutoFullscreen()
    }

    /** Dialogs on top of the video: no automatic fullscreen while one is open. */
    fun setModalOpen(open: Boolean) {
        modalOpen = open
        if (open) {
            handler.removeCallbacks(autoFullscreen)
        } else {
            onUserActivity()
        }
    }

    /** Returns true when Back was used up by the player. */
    fun handleBack(): Boolean = when (mode) {
        Mode.FULL -> {
            setMode(Mode.MINI)
            true
        }
        Mode.MINI -> {
            setMode(Mode.NONE)
            true
        }
        Mode.NONE -> false
    }

    /** Remote control and keyboard keys. Returns true when the player used the key. */
    fun handleKey(event: KeyEvent): Boolean {
        if (mode == Mode.NONE || event.action != KeyEvent.ACTION_DOWN) return false
        when (event.keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP -> {
                zap(forward = true)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                zap(forward = false)
                return true
            }
        }
        // Fullscreen with the controls hidden: the D-pad zaps, OK shows the controls.
        if (mode == Mode.FULL && !playerView.isControllerFullyVisible) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> {
                    zap(forward = true)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    zap(forward = false)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    playerView.showController()
                    return true
                }
            }
        }
        return false
    }

    fun onWindowFocusChanged(hasFocus: Boolean) {
        // System bars can come back after a dialog or the notification shade.
        if (hasFocus && mode == Mode.FULL) hideSystemBars()
    }

    fun onStart() {
        if (channel != null && mode != Mode.NONE) {
            // Live TV: jump back to the live edge instead of resuming old video.
            applyResolution()
            player.seekToDefaultPosition()
            player.prepare()
            player.playWhenReady = true
            if (mode == Mode.MINI) scheduleAutoFullscreen()
        }
    }

    fun onStop() {
        handler.removeCallbacks(autoFullscreen)
        // In Picture-in-Picture the video keeps playing; otherwise it pauses.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && activity.isInPictureInPictureMode) return
        player.pause()
    }

    /**
     * Home was pressed: if a video is playing, it moves into the system Picture-in-Picture
     * window (Android 8+, phones only; TV does not use it).
     */
    fun onUserLeaveHint() {
        if (isTv || mode == Mode.NONE || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (!player.playWhenReady) return
        if (mode == Mode.MINI) setMode(Mode.FULL)
        try {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            activity.enterPictureInPictureMode(params)
        } catch (e: Exception) {
            // Picture-in-Picture not allowed on this phone: the video simply pauses.
        }
    }

    fun onPictureInPictureModeChanged(isInPip: Boolean) {
        inPip = isInPip
        if (isInPip) {
            handler.removeCallbacks(autoFullscreen)
            indicator.visibility = View.GONE
            topBar.visibility = View.GONE
            playerView.useController = false
        } else if (mode == Mode.FULL) {
            playerView.useController = true
            hideSystemBars()
            playerView.showController()
        }
    }

    /** Applies the max-resolution choice from Settings (Auto = no limit). */
    private fun applyResolution() {
        val height = AppPrefs.maxVideoHeight(activity)
        val limit = if (height <= 0) Int.MAX_VALUE else height
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setMaxVideoSize(Int.MAX_VALUE, limit)
            .build()
    }

    fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        playerView.player = null
        player.release()
    }

    // ---- modes ----

    private fun setMode(newMode: Mode) {
        mode = newMode
        handler.removeCallbacks(autoFullscreen)
        handler.removeCallbacks(hideIndicator)
        indicator.visibility = View.GONE

        when (newMode) {
            Mode.NONE -> {
                playerView.isFocusable = false
                host.visibility = View.GONE
                player.stop()
                player.clearMediaItems()
                channel = null
                errorText.visibility = View.GONE
                showSystemBars()
                restoreBrightness()
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (!isTv) activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
            Mode.MINI -> {
                playerView.isFocusable = false
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                host.visibility = View.VISIBLE
                layoutMini()
                playerView.useController = false
                topBar.visibility = View.GONE
                closeButton.visibility = if (isTv) View.GONE else View.VISIBLE
                styleErrorText(small = true)
                showSystemBars()
                if (!isTv) activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                scheduleAutoFullscreen()
            }
            Mode.FULL -> {
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                host.visibility = View.VISIBLE
                layoutFull()
                closeButton.visibility = View.GONE
                styleErrorText(small = false)
                playerView.useController = true
                hideSystemBars()
                if (!isTv) {
                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                }
                playerView.showController()
                if (isTv) {
                    // Remote control: the buttons of the player take the focus.
                    playerView.isFocusable = true
                    playerView.requestFocus()
                }
            }
        }
    }

    private fun scheduleAutoFullscreen() {
        handler.removeCallbacks(autoFullscreen)
        if (modalOpen || mode != Mode.MINI) return
        val seconds = AppPrefs.autoFullscreenSeconds(activity)
        if (seconds > 0) handler.postDelayed(autoFullscreen, seconds * 1000L)
    }

    private fun layoutMini() {
        val params = FrameLayout.LayoutParams(miniWidth, miniHeight, Gravity.BOTTOM or Gravity.END)
        params.setMargins(margin, margin, margin, margin)
        host.layoutParams = params
        host.translationX = miniTx
        host.translationY = miniTy
        host.elevation = dp(8).toFloat()
        host.post { clampMini() }
    }

    private fun layoutFull() {
        host.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        host.translationX = 0f
        host.translationY = 0f
        host.elevation = 0f
    }

    /** Keeps the small video inside the screen, e.g. after the phone is turned. */
    private fun clampMini() {
        if (mode != Mode.MINI || root.width == 0 || root.height == 0) return
        val minX = -(root.width - miniWidth - margin).toFloat()
        val maxX = margin.toFloat()
        val minY = -(root.height - miniHeight - margin).toFloat()
        val maxY = margin.toFloat()
        if (minX > maxX || minY > maxY) return
        host.translationX = host.translationX.coerceIn(minX, maxX)
        host.translationY = host.translationY.coerceIn(minY, maxY)
        miniTx = host.translationX
        miniTy = host.translationY
    }

    private fun styleErrorText(small: Boolean) {
        errorText.textSize = if (small) 11f else 18f
        val h = if (small) dp(8) else dp(24)
        val v = if (small) dp(6) else dp(16)
        errorText.setPadding(h, v, h, v)
    }

    // ---- system bars ----

    private fun hideSystemBars() {
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        controller.show(WindowInsetsCompat.Type.systemBars())
    }

    // ---- player ----

    private fun buildPlayer() {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(AppInfo.USER_AGENT)
            .setAllowCrossProtocolRedirects(true) // many IPTV links redirect http -> https
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(15_000)

        // Start playing after ~1 s of data instead of the default 2.5 s.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_000, 2_500)
            .build()

        player = ExoPlayer.Builder(activity)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(loadControl)
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    errorText.visibility = View.GONE
                    networkRetries = 0
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
    }

    private fun startChannel(next: ChannelEntity, forceHls: Boolean = false) {
        if (!forceHls) {
            channel = next
            triedHls = false
            networkRetries = 0
            titleText.text = next.name
        }
        errorText.visibility = View.GONE
        applyResolution()

        val item = MediaItem.Builder().setUri(next.url).apply {
            // Links without ".m3u8" in them are treated as HLS on the retry.
            if (forceHls) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()

        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
    }

    private fun handleError(error: PlaybackException) {
        val current = channel ?: return
        when (error.errorCode) {
            PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW -> {
                player.seekToDefaultPosition()
                player.prepare()
            }
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED -> {
                if (!triedHls) {
                    triedHls = true
                    startChannel(current, forceHls = true)
                } else {
                    showError()
                }
            }
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> {
                if (networkRetries < MAX_NETWORK_RETRIES) {
                    networkRetries++
                    handler.postDelayed({ player.prepare() }, 1500L * networkRetries)
                } else {
                    showError()
                }
            }
            else -> showError()
        }
    }

    private fun showError() {
        errorText.visibility = View.VISIBLE
        if (mode == Mode.FULL) playerView.showController()
    }

    /** Moves to the next / previous channel of the list the user is looking at. */
    private fun zap(forward: Boolean) {
        val current = channel ?: return
        scope.launch {
            val other = navigator.neighbour(current, forward)
            if (other == null) {
                Toast.makeText(activity, R.string.no_more_channels, Toast.LENGTH_SHORT).show()
            } else {
                startChannel(other)
                onUserActivity()
            }
        }
    }

    // ---- views ----

    private fun buildViews() {
        playerView = PlayerView(activity).apply {
            player = this@PlayerHost.player
            controllerShowTimeoutMs = 4000
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
            useController = false
        }

        gestureDetector = GestureDetector(activity, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = 0
                return true
            }

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) {
                    playerView.hideController()
                } else {
                    playerView.showController()
                }
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                val start = e1 ?: return false
                if (gestureMode == 0) {
                    // Only vertical swipes count; the side where it started picks the control.
                    if (abs(distanceY) < abs(distanceX)) return false
                    if (start.x < playerView.width / 2f) {
                        gestureMode = 1
                        brightness = currentBrightness()
                    } else {
                        gestureMode = 2
                        volumeLevel = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                    }
                }
                // distanceY is positive when the finger moves up.
                val change = distanceY / playerView.height.toFloat().coerceAtLeast(1f)
                if (gestureMode == 1) changeBrightness(change) else changeVolume(change)
                return true
            }
        })

        playerView.setOnTouchListener { _, event ->
            if (mode == Mode.MINI) {
                handleMiniTouch(event)
            } else {
                gestureDetector.onTouchEvent(event)
                if (event.actionMasked == MotionEvent.ACTION_UP ||
                    event.actionMasked == MotionEvent.ACTION_CANCEL
                ) {
                    handler.removeCallbacks(hideIndicator)
                    handler.postDelayed(hideIndicator, 700)
                }
                true
            }
        }

        titleText = TextView(activity).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }

        val previous = ImageButton(activity).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { zap(forward = false) }
        }
        val nextButton = ImageButton(activity).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { zap(forward = true) }
        }
        val minimizeButton = Button(activity).apply {
            text = activity.getString(R.string.minimize)
            textSize = 12f
            setOnClickListener { setMode(Mode.MINI) }
        }

        topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(12), dp(8), dp(8), dp(8))
            addView(titleText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(previous)
            addView(nextButton)
            if (!isTv) addView(minimizeButton)
            visibility = View.GONE
        }

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility ->
                topBar.visibility = if (mode == Mode.FULL) visibility else View.GONE
            }
        )

        closeButton = ImageButton(activity).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            contentDescription = activity.getString(R.string.close_video)
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { closePlayer() }
        }

        indicator = TextView(activity).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = GradientDrawable().apply {
                setColor(0xAA000000.toInt())
                cornerRadius = dp(12).toFloat()
            }
            visibility = View.GONE
        }

        errorText = TextView(activity).apply {
            text = activity.getString(R.string.play_failed)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0xCC8B0000.toInt())
                cornerRadius = dp(12).toFloat()
            }
            visibility = View.GONE
        }
        styleErrorText(small = true)

        val wrap = FrameLayout.LayoutParams.WRAP_CONTENT
        val match = FrameLayout.LayoutParams.MATCH_PARENT
        host = FrameLayout(activity).apply {
            setBackgroundColor(Color.BLACK)
            // The small video must never take D-pad focus away from the channel list (TV).
            isFocusable = false
            addView(playerView, FrameLayout.LayoutParams(match, match))
            addView(topBar, FrameLayout.LayoutParams(match, wrap, Gravity.TOP))
            addView(indicator, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))
            addView(errorText, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))
            addView(
                closeButton,
                FrameLayout.LayoutParams(dp(32), dp(32), Gravity.TOP or Gravity.END)
            )
        }
    }

    // ---- small video: drag, tap ----

    private fun handleMiniTouch(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                startTx = host.translationX
                startTy = host.translationY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!dragging && hypot(dx, dy) > touchSlop) dragging = true
                if (dragging) {
                    host.translationX = startTx + dx
                    host.translationY = startTy + dy
                    clampMini()
                }
            }
            MotionEvent.ACTION_UP -> {
                // A tap, not a drag: go fullscreen.
                if (!dragging) setMode(Mode.FULL)
            }
        }
        return true
    }

    // ---- gestures: brightness and volume ----

    private fun currentBrightness(): Float {
        val set = activity.window.attributes.screenBrightness
        if (set >= 0f) return set
        return try {
            Settings.System.getInt(activity.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun changeBrightness(change: Float) {
        brightness = (brightness + change).coerceIn(0.02f, 1f)
        val params = activity.window.attributes
        params.screenBrightness = brightness
        activity.window.attributes = params
        showIndicator(activity.getString(R.string.brightness, (brightness * 100).roundToInt()))
    }

    /** Back to the phone's own brightness once the video is closed. */
    private fun restoreBrightness() {
        val params = activity.window.attributes
        if (params.screenBrightness != WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE) {
            params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            activity.window.attributes = params
        }
    }

    private fun changeVolume(change: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()
        volumeLevel = (volumeLevel + change * max).coerceIn(0f, max)
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, volumeLevel.roundToInt(), 0)
        } catch (e: SecurityException) {
            // Some phones refuse volume changes in Do Not Disturb mode.
        }
        val percent = if (max > 0f) (volumeLevel / max * 100).roundToInt() else 0
        showIndicator(activity.getString(R.string.volume, percent))
    }

    private fun showIndicator(text: String) {
        handler.removeCallbacks(hideIndicator)
        indicator.text = text
        indicator.visibility = View.VISIBLE
    }
}
