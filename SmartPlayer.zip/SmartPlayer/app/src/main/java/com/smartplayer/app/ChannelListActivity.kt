package com.smartplayer.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.paging.LoadState
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load
import com.smartplayer.app.data.ChannelEntity
import com.smartplayer.app.data.SmartDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

private val CHANNEL_DIFF = object : DiffUtil.ItemCallback<ChannelEntity>() {
    override fun areItemsTheSame(oldItem: ChannelEntity, newItem: ChannelEntity) =
        oldItem.id == newItem.id

    override fun areContentsTheSame(oldItem: ChannelEntity, newItem: ChannelEntity) =
        oldItem == newItem
}

private class ChannelViewHolder(
    val row: LinearLayout,
    val logo: ImageView,
    val name: TextView,
    val group: TextView
) : RecyclerView.ViewHolder(row)

/**
 * Step 4: channel list for one playlist. Rows are loaded page by page from the
 * database, so a playlist with 20,000+ channels scrolls and searches smoothly.
 */
class ChannelListActivity : Activity() {

    companion object {
        const val EXTRA_PLAYLIST_ID = "playlist_id"
        const val EXTRA_PLAYLIST_NAME = "playlist_name"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: SmartDatabase
    private lateinit var adapter: ChannelAdapter
    private lateinit var groupButton: Button
    private lateinit var emptyText: TextView

    private var playlistId = -1L
    private var group = ""
    private var query = ""
    private var groups: List<String> = emptyList()
    private var pagingJob: Job? = null

    private val searchTask = Runnable {
        query = searchInput.text.toString().trim()
        reload()
    }
    private lateinit var searchInput: EditText

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        playlistId = intent.getLongExtra(EXTRA_PLAYLIST_ID, -1L)
        if (playlistId < 0) {
            finish()
            return
        }
        db = SmartDatabase.get(applicationContext)
        adapter = ChannelAdapter()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(28), dp(12), dp(8))
        }

        root.addView(TextView(this).apply {
            text = intent.getStringExtra(EXTRA_PLAYLIST_NAME) ?: getString(R.string.app_name)
            textSize = 20f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })

        searchInput = EditText(this).apply {
            hint = getString(R.string.search_hint)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            doAfterTextChanged {
                // Wait until typing pauses, then search.
                handler.removeCallbacks(searchTask)
                handler.postDelayed(searchTask, 300)
            }
        }
        root.addView(searchInput)

        groupButton = Button(this).apply {
            text = getString(R.string.all_groups)
            setOnClickListener { showGroupDialog() }
        }
        root.addView(groupButton)

        emptyText = TextView(this).apply {
            text = getString(R.string.no_results)
            setPadding(dp(8), dp(16), dp(8), dp(8))
            visibility = View.GONE
        }
        root.addView(emptyText)

        val list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@ChannelListActivity)
            adapter = this@ChannelListActivity.adapter
            setHasFixedSize(true)
        }
        root.addView(list, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)

        adapter.addLoadStateListener { states ->
            val empty = states.refresh is LoadState.NotLoading && adapter.itemCount == 0
            emptyText.visibility = if (empty) View.VISIBLE else View.GONE
        }

        scope.launch {
            groups = db.channelDao().groups(playlistId).filter { it.isNotEmpty() }
        }
        reload()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(searchTask)
        scope.cancel()
    }

    /** Starts a fresh page stream for the current search text and group. */
    private fun reload() {
        pagingJob?.cancel()
        pagingJob = scope.launch {
            Pager(PagingConfig(pageSize = 60, enablePlaceholders = false)) {
                db.channelDao().pagingSource(playlistId, group, query)
            }.flow.collectLatest { adapter.submitData(it) }
        }
    }

    private fun showGroupDialog() {
        val options = (listOf(getString(R.string.all_groups)) + groups).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.group_title)
            .setItems(options) { _, which ->
                group = if (which == 0) "" else groups[which - 1]
                groupButton.text = options[which]
                reload()
            }
            .show()
    }

    private inner class ChannelAdapter :
        PagingDataAdapter<ChannelEntity, ChannelViewHolder>(CHANNEL_DIFF) {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
            val ctx = parent.context
            val logo = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            }
            val name = TextView(ctx).apply {
                textSize = 16f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val group = TextView(ctx).apply {
                textSize = 12f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val texts = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(name)
                addView(group)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { leftMargin = dp(12) }
            }
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true // lets a TV remote highlight and select rows
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                addView(logo)
                addView(texts)
            }
            val ripple = TypedValue()
            if (ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)) {
                row.setBackgroundResource(ripple.resourceId)
            }
            return ChannelViewHolder(row, logo, name, group)
        }

        override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
            val channel = getItem(position) ?: return
            holder.name.text = channel.name
            holder.group.text = channel.groupTitle
            holder.group.visibility = if (channel.groupTitle.isEmpty()) View.GONE else View.VISIBLE

            val logoUrl = channel.logoUrl
            if (logoUrl.isNullOrEmpty()) {
                holder.logo.dispose()
                holder.logo.setImageDrawable(null)
            } else {
                holder.logo.load(logoUrl)
            }

            holder.row.setOnClickListener {
                // The player gets the current group and search text so that
                // channel up/down follows the list the user is looking at.
                startActivity(
                    Intent(this@ChannelListActivity, PlayerActivity::class.java)
                        .putExtra(PlayerActivity.EXTRA_CHANNEL_ID, channel.id)
                        .putExtra(PlayerActivity.EXTRA_GROUP, group)
                        .putExtra(PlayerActivity.EXTRA_QUERY, query)
                )
            }
        }
    }
}
