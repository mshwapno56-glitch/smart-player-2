package com.smartplayer.app.parser

import java.io.BufferedReader

data class ParsedChannel(
    val name: String,
    val groupTitle: String,
    val logoUrl: String?,
    val tvgId: String?,
    val url: String
)

/**
 * Streaming M3U parser. Reads line by line (never loads the whole file into
 * memory) and hands channels to [onBatch] in groups, so very large playlists
 * (20,000+ channels) stay cheap on memory and can be written to the database
 * in chunks.
 */
object M3uParser {

    private val ATTR = Regex("""([\w-]+)="([^"]*)"""")

    /** Returns the number of channels parsed. */
    suspend fun parse(
        reader: BufferedReader,
        batchSize: Int = 1000,
        onBatch: suspend (List<ParsedChannel>) -> Unit
    ): Int {
        var batch = ArrayList<ParsedChannel>(batchSize)
        var total = 0

        var pendingName: String? = null
        var pendingGroup = ""
        var pendingLogo: String? = null
        var pendingTvgId: String? = null
        var extGrp: String? = null

        while (true) {
            val raw = reader.readLine() ?: break
            val line = raw.trim()
            if (line.isEmpty()) continue

            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val info = parseExtInf(line)
                    pendingName = info.name
                    pendingGroup = info.group
                    pendingLogo = info.logo
                    pendingTvgId = info.tvgId
                }
                line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                    extGrp = line.substringAfter(':').trim()
                }
                line.startsWith("#") -> {
                    // #EXTM3U, #EXTVLCOPT and other directives are ignored
                }
                else -> {
                    // A non-comment line is the stream URL for the last #EXTINF
                    if (pendingName != null) {
                        val group = pendingGroup.ifEmpty { extGrp ?: "" }
                        batch.add(
                            ParsedChannel(
                                name = pendingName.ifEmpty { line },
                                groupTitle = group,
                                logoUrl = pendingLogo,
                                tvgId = pendingTvgId,
                                url = line
                            )
                        )
                        total++
                        if (batch.size >= batchSize) {
                            onBatch(batch)
                            batch = ArrayList(batchSize)
                        }
                    }
                    pendingName = null
                    pendingGroup = ""
                    pendingLogo = null
                    pendingTvgId = null
                    extGrp = null
                }
            }
        }
        if (batch.isNotEmpty()) onBatch(batch)
        return total
    }

    internal data class ExtInf(
        val name: String,
        val group: String,
        val logo: String?,
        val tvgId: String?
    )

    internal fun parseExtInf(line: String): ExtInf {
        val body = line.substringAfter(':', "")

        // The display name follows the first comma that is outside quotes.
        var inQuotes = false
        var commaIndex = -1
        for (i in body.indices) {
            val c = body[i]
            if (c == '"') inQuotes = !inQuotes
            else if (c == ',' && !inQuotes) {
                commaIndex = i
                break
            }
        }
        val attrPart = if (commaIndex >= 0) body.substring(0, commaIndex) else body
        val name = if (commaIndex >= 0) body.substring(commaIndex + 1).trim() else ""

        var group = ""
        var logo: String? = null
        var tvgId: String? = null
        for (m in ATTR.findAll(attrPart)) {
            val value = m.groupValues[2]
            when (m.groupValues[1].lowercase()) {
                "group-title" -> group = value
                "tvg-logo" -> logo = value.ifEmpty { null }
                "tvg-id" -> tvgId = value.ifEmpty { null }
            }
        }
        return ExtInf(name, group, logo, tvgId)
    }
}
