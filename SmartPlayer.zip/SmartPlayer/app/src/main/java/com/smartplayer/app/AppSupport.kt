package com.smartplayer.app

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.util.Locale

object AppInfo {
    /** Same User-Agent for playback and for the online check, so both see the same server answer. */
    const val USER_AGENT = "SmartPlayer/0.1 (Android)"
}

/** Small settings stored on the phone (language, current playlist, auto fullscreen). */
object AppPrefs {
    private const val FILE = "smart_player"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_CURRENT_PLAYLIST = "current_playlist"
    private const val KEY_AUTO_FULLSCREEN_SECONDS = "auto_fullscreen_seconds"

    const val DEFAULT_AUTO_FULLSCREEN_SECONDS = 4

    /** The choices shown in Settings; 0 means "off". */
    val AUTO_FULLSCREEN_CHOICES = listOf(0, 3, 4, 5, 10)

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** "" = follow the phone, "en" = English, "bn" = Bangla. */
    fun language(context: Context): String =
        prefs(context).getString(KEY_LANGUAGE, "") ?: ""

    fun setLanguage(context: Context, code: String) {
        prefs(context).edit().putString(KEY_LANGUAGE, code).apply()
    }

    /** The playlist whose channels the main screen shows; -1 = none chosen yet. */
    fun currentPlaylistId(context: Context): Long =
        prefs(context).getLong(KEY_CURRENT_PLAYLIST, -1L)

    fun setCurrentPlaylistId(context: Context, id: Long) {
        prefs(context).edit().putLong(KEY_CURRENT_PLAYLIST, id).apply()
    }

    /**
     * Seconds the small floating video waits before it turns fullscreen by itself.
     * 0 = never.
     */
    fun autoFullscreenSeconds(context: Context): Int =
        prefs(context).getInt(KEY_AUTO_FULLSCREEN_SECONDS, DEFAULT_AUTO_FULLSCREEN_SECONDS)

    fun setAutoFullscreenSeconds(context: Context, seconds: Int) {
        prefs(context).edit().putInt(KEY_AUTO_FULLSCREEN_SECONDS, seconds).apply()
    }
}

/**
 * A scope that lives as long as the app process. Playlist downloads run here so that
 * leaving the playlist screen does not cancel a download half way through.
 */
object AppScope {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
}

object PlaylistLoader {
    /** True while a playlist is being downloaded or imported. */
    @Volatile var busy = false
}

object DeviceUtil {
    fun isTv(context: Context): Boolean {
        val ui = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    }
}

/**
 * Applies the language chosen in Settings. Each activity calls [wrap] from
 * attachBaseContext, so its strings come from values/ or values-bn/.
 */
object LocaleHelper {
    fun wrap(base: Context): Context {
        val code = AppPrefs.language(base)
        if (code.isEmpty()) return base
        val locale = Locale(code)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
