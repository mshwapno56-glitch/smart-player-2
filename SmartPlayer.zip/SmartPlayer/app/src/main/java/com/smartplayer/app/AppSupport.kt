package com.smartplayer.app

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import java.util.Locale

/** Small settings stored on the phone (language, fullscreen behaviour). */
object AppPrefs {
    private const val FILE = "smart_player"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_AUTO_FULLSCREEN = "auto_fullscreen"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** "" = follow the phone, "en" = English, "bn" = Bangla. */
    fun language(context: Context): String =
        prefs(context).getString(KEY_LANGUAGE, "") ?: ""

    fun setLanguage(context: Context, code: String) {
        prefs(context).edit().putString(KEY_LANGUAGE, code).apply()
    }

    /** Phone only: hide the system bars and go landscape when playback starts. */
    fun autoFullscreen(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_FULLSCREEN, true)

    fun setAutoFullscreen(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_FULLSCREEN, value).apply()
    }
}

object DeviceUtil {
    fun isTv(context: Context): Boolean {
        val ui = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    }
}

/**
 * Applies the language chosen in Settings. Each activity calls [wrap] from
 * attachBaseContext, so its strings come from values/ or values-bn/.
 */
object LocaleHelper {
    fun wrap(base: Context): Context {
        val code = AppPrefs.language(base)
        if (code.isEmpty()) return base
        val locale = Locale(code)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
