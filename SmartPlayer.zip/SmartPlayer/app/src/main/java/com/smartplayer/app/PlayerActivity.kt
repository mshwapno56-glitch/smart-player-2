package com.smartplayer.app

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.smartplayer.app.data.ChannelEntity
import com.smartplayer.app.data.SmartDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Step 5: full-screen player.
 *
 * - Media3 (ExoPlayer) with a small start-up buffer so channels open quickly.
 * - Swipe up/down on the left half = brightness, right half = volume.
 * - Fullscreen: automatic on TV, an option in Settings on phones.
 * - Channel up/down (buttons, remote keys) moves through the same list the
 *   user came from, including its group filter and search text.
 */
class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_CHANNEL_ID = "channel_id"
        const val EXTRA_GROUP = "group"
        const val EXTRA_QUERY = "query"
        private const val MAX_NETWORK_RETRIES = 3
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var db: SmartDatabase
    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var topBar: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var indicator: TextView
    private lateinit var errorText: TextView
    private lateinit var audio: AudioManager
    private lateinit var gestureDetector: GestureDetector

    private var isTv = false
    private var fullscreen = false

    private var channel: ChannelEntity? = null
    private var group = ""
    private var query = ""

    private var triedHls = false
    private var networkRetries = 0

    // gesture state: 0 = none, 1 = brightness, 2 = volume
    private var gestureMode = 0
    private var brightness = 0.5f
    private var volumeLevel = 0f

    private val hideIndicator = Runnable { indicator.visibility = View.GONE }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = SmartDatabase.get(applicationContext)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        isTv = DeviceUtil.isTv(this)
        group = intent.getStringExtra(EXTRA_GROUP) ?: ""
        query = intent.getStringExtra(EXTRA_QUERY) ?: ""

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        buildPlayer()
        buildUi()
        setContentView(buildRoot())

        // Fullscreen: always on TV, a setting on phones.
        setFullscreen(isTv || AppPrefs.autoFullscreen(this))

        val channelId = intent.getLongExtra(EXTRA_CHANNEL_ID, -1L)
        scope.launch {
            val first = db.channelDao().getChannel(channelId)
            if (first == null) finish() else playChannel(first)
        }
    }

    // ---- player ----

    private fun buildPlayer() {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true) // many IPTV links redirect http -> https
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(15_000)

        // Start playing after ~1 s of data instead of the default 2.5 s.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_000, 2_500)
            .build()

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(loadControl)
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    errorText.visibility = View.GONE
                    networkRetries = 0
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
    }

    private fun playChannel(next: ChannelEntity, forceHls: Boolean = false) {
        if (!forceHls) {
            channel = next
            triedHls = false
            networkRetries = 0
            titleText.text = next.name
        }
        errorText.visibility = View.GONE

        val item = MediaItem.Builder().setUri(next.url).apply {
            // Links without ".m3u8" in them are treated as HLS on the retry.
            if (forceHls) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()

        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
    }

    private fun handleError(error: PlaybackException) {
        val current = channel ?: return
        when (error.errorCode) {
            PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW -> {
                player.seekToDefaultPosition()
                player.prepare()
            }
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED -> {
                if (!triedHls) {
                    triedHls = true
                    playChannel(current, forceHls = true)
                } else {
                    showError()
                }
            }
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> {
                if (networkRetries < MAX_NETWORK_RETRIES) {
                    networkRetries++
                    handler.postDelayed({ player.prepare() }, 1500L * networkRetries)
                } else {
                    showError()
                }
            }
            else -> showError()
        }
    }

    private fun showError() {
        errorText.visibility = View.VISIBLE
        playerView.showController()
    }

    /** Moves to the next / previous channel of the list the user came from. */
    private fun zap(forward: Boolean) {
        val current = channel ?: return
        scope.launch {
            val dao = db.channelDao()
            val other = if (forward) {
                dao.nextChannel(current.playlistId, current.id, group, query)
            } else {
                dao.previousChannel(current.playlistId, current.id, group, query)
            }
            if (other == null) {
                Toast.makeText(this@PlayerActivity, R.string.no_more_channels, Toast.LENGTH_SHORT).show()
            } else {
                playChannel(other)
            }
        }
    }

    // ---- UI ----

    private fun buildUi() {
        playerView = PlayerView(this).apply {
            player = this@PlayerActivity.player
            controllerShowTimeoutMs = 4000
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
        }

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = 0
                return true
            }

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) {
                    playerView.hideController()
                } else {
                    playerView.showController()
                }
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                val start = e1 ?: return false
                if (gestureMode == 0) {
                    // Only vertical swipes count; the side where it started picks the control.
                    if (abs(distanceY) < abs(distanceX)) return false
                    if (start.x < playerView.width / 2f) {
                        gestureMode = 1
                        brightness = currentBrightness()
                    } else {
                        gestureMode = 2
                        volumeLevel = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                    }
                }
                // distanceY is positive when the finger moves up.
                val change = distanceY / playerView.height.toFloat().coerceAtLeast(1f)
                if (gestureMode == 1) changeBrightness(change) else changeVolume(change)
                return true
            }
        })

        playerView.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            if (event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                handler.removeCallbacks(hideIndicator)
                handler.postDelayed(hideIndicator, 700)
            }
            true
        }

        titleText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val previous = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { zap(forward = false) }
        }
        val nextButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { zap(forward = true) }
        }
        val fullscreenButton = Button(this).apply {
            text = getString(R.string.fullscreen)
            textSize = 12f
            setOnClickListener { setFullscreen(!fullscreen) }
        }

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(12), dp(8), dp(8), dp(8))
            addView(titleText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(previous)
            addView(nextButton)
            if (!isTv) addView(fullscreenButton)
        }

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility -> topBar.visibility = visibility }
        )

        indicator = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = GradientDrawable().apply {
                setColor(0xAA000000.toInt())
                cornerRadius = dp(12).toFloat()
            }
            visibility = View.GONE
        }

        errorText = TextView(this).apply {
            text = getString(R.string.play_failed)
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(16), dp(24), dp(16))
            background = GradientDrawable().apply {
                setColor(0xCC8B0000.toInt())
                cornerRadius = dp(12).toFloat()
            }
            visibility = View.GONE
        }
    }

    private fun buildRoot(): FrameLayout {
        val match = FrameLayout.LayoutParams.MATCH_PARENT
        return FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(playerView, FrameLayout.LayoutParams(match, match))
            addView(topBar, FrameLayout.LayoutParams(match, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))
            addView(
                indicator,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
            addView(
                errorText,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }
    }

    // ---- gestures: brightness and volume ----

    private fun currentBrightness(): Float {
        val set = window.attributes.screenBrightness
        if (set >= 0f) return set
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun changeBrightness(change: Float) {
        brightness = (brightness + change).coerceIn(0.02f, 1f)
        val params = window.attributes
        params.screenBrightness = brightness
        window.attributes = params
        showIndicator(getString(R.string.brightness, (brightness * 100).roundToInt()))
    }

    private fun changeVolume(change: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()
        volumeLevel = (volumeLevel + change * max).coerceIn(0f, max)
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, volumeLevel.roundToInt(), 0)
        } catch (e: SecurityException) {
            // Some phones refuse volume changes in Do Not Disturb mode.
        }
        val percent = if (max > 0f) (volumeLevel / max * 100).roundToInt() else 0
        showIndicator(getString(R.string.volume, percent))
    }

    private fun showIndicator(text: String) {
        handler.removeCallbacks(hideIndicator)
        indicator.text = text
        indicator.visibility = View.VISIBLE
    }

    // ---- fullscreen ----

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        applySystemBars()
        if (!isTv) {
            requestedOrientation = if (on) {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    private fun applySystemBars() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (fullscreen) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // System bars can come back after a dialog or the notification shade.
        if (hasFocus && fullscreen) applySystemBars()
    }

    // ---- remote control (TV) ----

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP -> {
                    zap(forward = true)
                    return true
                }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    zap(forward = false)
                    return true
                }
            }
            // With the controls hidden, the D-pad zaps; OK shows the controls.
            if (!playerView.isControllerFullyVisible) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        zap(forward = true)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        zap(forward = false)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        playerView.showController()
                        return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ---- lifecycle ----

    override fun onStart() {
        super.onStart()
        if (channel != null) {
            // Live TV: jump back to the live edge instead of resuming old video.
            player.seekToDefaultPosition()
            player.prepare()
            player.playWhenReady = true
        }
    }

    override fun onStop() {
        super.onStop()
        player.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        playerView.player = null
        player.release()
    }
}
