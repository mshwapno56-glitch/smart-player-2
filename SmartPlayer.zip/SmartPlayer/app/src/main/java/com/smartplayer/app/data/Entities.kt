package com.smartplayer.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val url: String,
    val addedAt: Long = System.currentTimeMillis(),
    val lastUpdated: Long = 0,
    val etag: String? = null,
    val channelCount: Int = 0
)

@Entity(
    tableName = "channels",
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    // One composite index only: it also serves lookups by playlistId alone.
    // Fewer indexes means much faster bulk inserts.
    indices = [
        Index("playlistId", "groupTitle")
    ]
)
data class ChannelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val name: String,
    val groupTitle: String,
    val logoUrl: String?,
    val tvgId: String?,
    val url: String,
    /** See [ChannelStatus]. A refreshed playlist starts again from UNKNOWN. */
    @ColumnInfo(defaultValue = "0") val status: Int = ChannelStatus.UNKNOWN,
    @ColumnInfo(defaultValue = "0") val checkedAt: Long = 0
)

/** Result of the online check for one channel. */
object ChannelStatus {
    const val UNKNOWN = 0
    const val ONLINE = 1
    const val OFFLINE = 2
}
