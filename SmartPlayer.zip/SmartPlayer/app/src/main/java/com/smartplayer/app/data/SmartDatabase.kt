package com.smartplayer.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [PlaylistEntity::class, ChannelEntity::class],
    version = 3,
    exportSchema = false
)
abstract class SmartDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun channelDao(): ChannelDao

    companion object {
        @Volatile private var instance: SmartDatabase? = null

        /** Adds the online/offline check columns; existing channels start as UNKNOWN. */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE channels ADD COLUMN status INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE channels ADD COLUMN checkedAt INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun get(context: Context): SmartDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SmartDatabase::class.java,
                    "smart_player.db"
                )
                    // 2 -> 3 keeps the saved playlists and channels.
                    .addMigrations(MIGRATION_2_3)
                    // Early development only: older schemas (1) may still be reset.
                    // Replace with real migrations before the app is shared.
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
    }
}
