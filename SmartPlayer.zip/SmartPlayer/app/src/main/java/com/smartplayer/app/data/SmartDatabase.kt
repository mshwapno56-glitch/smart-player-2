package com.smartplayer.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PlaylistEntity::class, ChannelEntity::class],
    version = 2,
    exportSchema = false
)
abstract class SmartDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun channelDao(): ChannelDao

    companion object {
        @Volatile private var instance: SmartDatabase? = null

        fun get(context: Context): SmartDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SmartDatabase::class.java,
                    "smart_player.db"
                )
                    // Early development only: no real user data yet, so a schema
                    // change may reset the database. Replace with real migrations
                    // before the app is shared.
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
    }
}
