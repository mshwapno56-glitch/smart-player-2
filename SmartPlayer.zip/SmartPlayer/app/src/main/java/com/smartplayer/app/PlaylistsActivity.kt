package com.smartplayer.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.smartplayer.app.data.PlaylistEntity
import com.smartplayer.app.data.PlaylistRepository
import com.smartplayer.app.data.SmartDatabase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Settings > Playlists. Add, edit, delete and update M3U links. Tapping a playlist makes it
 * the current one and returns to the main screen, which then shows its channels.
 * Playlists are never merged.
 */
class PlaylistsActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var db: SmartDatabase
    private lateinit var repo: PlaylistRepository
    private lateinit var adapter: PlaylistAdapter
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var debugButton: Button
    private lateinit var debugOutput: TextView

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = SmartDatabase.get(applicationContext)
        repo = PlaylistRepository(db, cacheDir)
        adapter = PlaylistAdapter()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(12))
        }

        root.addView(TextView(this).apply {
            text = getString(R.string.playlists)
            textSize = 24f
        })

        root.addView(Button(this).apply {
            text = getString(R.string.add_playlist)
            setOnClickListener {
                if (PlaylistLoader.busy) toastBusy() else showPlaylistDialog(null)
            }
        })

        root.addView(TextView(this).apply {
            text = getString(R.string.list_hint)
            textSize = 12f
        })

        statusText = TextView(this).apply { visibility = View.GONE }
        root.addView(statusText)

        progress = ProgressBar(this).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        root.addView(progress)

        val list = ListView(this)
        val emptyText = TextView(this).apply {
            text = getString(R.string.empty_list)
            setPadding(dp(8), dp(24), dp(8), dp(8))
            visibility = View.GONE
        }
        list.adapter = adapter
        // Tap: make it the current playlist and show its channels. Long-press: options.
        list.setOnItemClickListener { _, _, position, _ ->
            val playlist = adapter.items[position]
            AppPrefs.setCurrentPlaylistId(this, playlist.id)
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
            finish()
        }
        list.setOnItemLongClickListener { _, _, position, _ ->
            if (PlaylistLoader.busy) toastBusy() else showPlaylistMenu(adapter.items[position])
            true
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(emptyText)
        list.emptyView = emptyText

        debugOutput = TextView(this).apply { visibility = View.GONE }
        root.addView(debugOutput)
        debugButton = Button(this).apply {
            text = getString(R.string.debug_test)
            setOnClickListener { runDebugTest() }
        }
        root.addView(debugButton)

        setContentView(root)

        scope.launch {
            repo.observePlaylists().collect { adapter.items = it }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    private fun toastBusy() {
        Toast.makeText(this, R.string.busy, Toast.LENGTH_SHORT).show()
    }

    // ---- list ----

    private inner class PlaylistAdapter : BaseAdapter() {
        var items: List<PlaylistEntity> = emptyList()
            set(value) {
                field = value
                notifyDataSetChanged()
            }

        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@PlaylistsActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(12), dp(8), dp(12))
                addView(TextView(context).apply { textSize = 18f })
                addView(TextView(context).apply {
                    textSize = 13f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
            }
            val playlist = items[position]
            val isCurrent = playlist.id == AppPrefs.currentPlaylistId(this@PlaylistsActivity)
            (row.getChildAt(0) as TextView).text =
                if (isCurrent) "✓ ${playlist.name}" else playlist.name
            (row.getChildAt(1) as TextView).text = subtitle(playlist)
            return row
        }

        private fun subtitle(p: PlaylistEntity): String {
            val count = if (p.lastUpdated > 0) {
                getString(R.string.channels_count, p.channelCount)
            } else {
                getString(R.string.never_updated)
            }
            return "$count · ${p.url}"
        }
    }

    // ---- dialogs ----

    private fun showPlaylistMenu(playlist: PlaylistEntity) {
        val options = arrayOf(
            getString(R.string.update),
            getString(R.string.edit),
            getString(R.string.delete)
        )
        AlertDialog.Builder(this)
            .setTitle(playlist.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> load(playlist, force = false)
                    1 -> showPlaylistDialog(playlist)
                    2 -> confirmDelete(playlist)
                }
            }
            .show()
    }

    private fun confirmDelete(playlist: PlaylistEntity) {
        val appContext = applicationContext
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_confirm_title)
            .setMessage(getString(R.string.delete_confirm_msg, playlist.name))
            .setPositiveButton(R.string.delete) { _, _ ->
                AppScope.scope.launch {
                    repo.deletePlaylist(playlist)
                    // If the current playlist was deleted, the newest remaining one takes over.
                    if (AppPrefs.currentPlaylistId(appContext) == playlist.id) {
                        AppPrefs.setCurrentPlaylistId(appContext, repo.newestPlaylist()?.id ?: -1L)
                        if (!isDestroyed) adapter.notifyDataSetChanged()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** Add dialog when [existing] is null, edit dialog otherwise. */
    private fun showPlaylistDialog(existing: PlaylistEntity?) {
        val nameInput = EditText(this).apply {
            hint = getString(R.string.name_hint)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setText(existing?.name ?: "")
        }
        val urlInput = EditText(this).apply {
            hint = getString(R.string.url_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(existing?.url ?: "")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(nameInput)
            addView(urlInput)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) R.string.add_playlist else R.string.edit_playlist)
            .setView(box)
            .setPositiveButton(R.string.save, null)
            .setNegativeButton(R.string.cancel, null)
            .create()
        dialog.show()

        // Set after show() so a validation error keeps the dialog open.
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val name = nameInput.text.toString().trim()
            val url = urlInput.text.toString().trim()
            var valid = true
            if (name.isEmpty()) {
                nameInput.error = getString(R.string.error_name)
                valid = false
            }
            if (!url.startsWith("http://", ignoreCase = true) &&
                !url.startsWith("https://", ignoreCase = true)
            ) {
                urlInput.error = getString(R.string.error_url)
                valid = false
            }
            if (!valid) return@setOnClickListener

            dialog.dismiss()
            val appContext = applicationContext
            scope.launch {
                val id = if (existing == null) {
                    repo.addPlaylist(name, url).also {
                        // The playlist just added is the one the main screen shows first.
                        AppPrefs.setCurrentPlaylistId(appContext, it)
                    }
                } else {
                    repo.renamePlaylist(existing, name, url)
                    existing.id
                }
                repo.getPlaylist(id)?.let { load(it, force = true) }
            }
        }
    }

    // ---- loading ----
    // Runs in the app-wide scope, so leaving this screen does not cancel the download.

    private fun load(playlist: PlaylistEntity, force: Boolean) {
        if (PlaylistLoader.busy) return
        PlaylistLoader.busy = true
        progress.visibility = View.VISIBLE
        statusText.visibility = View.VISIBLE
        statusText.text = getString(R.string.loading_progress, 0)
        val appContext = applicationContext

        AppScope.scope.launch {
            val message = try {
                val result = repo.refresh(playlist, force) { count ->
                    runOnUiThread {
                        if (!isDestroyed) {
                            statusText.text = appContext.getString(R.string.loading_progress, count)
                        }
                    }
                }
                if (result.notModified) {
                    getString(R.string.up_to_date)
                } else {
                    getString(R.string.done_loaded, result.channels)
                }
            } catch (e: CancellationException) {
                PlaylistLoader.busy = false
                throw e
            } catch (e: Exception) {
                getString(R.string.load_failed, e.message ?: e.javaClass.simpleName)
            }
            PlaylistLoader.busy = false
            if (!isDestroyed) {
                progress.visibility = View.GONE
                statusText.text = message
                adapter.notifyDataSetChanged()
            }
        }
    }

    // ---- debug speed test ----

    private fun runDebugTest() {
        if (PlaylistLoader.busy) {
            toastBusy()
            return
        }
        PlaylistLoader.busy = true
        debugButton.isEnabled = false
        debugOutput.visibility = View.VISIBLE
        debugOutput.text = getString(R.string.debug_running)

        scope.launch {
            val text = try {
                withContext(Dispatchers.IO) {
                    val file = File(cacheDir, "bench.m3u")

                    val genStart = System.nanoTime()
                    file.bufferedWriter().use { w ->
                        w.write("#EXTM3U\n")
                        for (i in 1..100_000) {
                            w.write(
                                "#EXTINF:-1 tvg-id=\"ch$i\" tvg-logo=\"http://example.com/$i.png\" " +
                                    "group-title=\"Group ${i % 50}\",Channel $i\n"
                            )
                            w.write("http://example.com/live/$i.m3u8\n")
                        }
                    }
                    val genMs = (System.nanoTime() - genStart) / 1_000_000

                    val parseStart = System.nanoTime()
                    repo.parseOnly(file)
                    val parseMs = (System.nanoTime() - parseStart) / 1_000_000

                    val id = repo.addPlaylist("Benchmark", "http://example.com/bench.m3u")
                    val importStart = System.nanoTime()
                    repo.importFile(id, file)
                    val importMs = (System.nanoTime() - importStart) / 1_000_000

                    repo.getPlaylist(id)?.let { repo.deletePlaylist(it) }
                    val left = db.channelDao().count(id)
                    file.delete()

                    getString(R.string.debug_result, genMs, parseMs, importMs, left)
                }
            } catch (e: CancellationException) {
                PlaylistLoader.busy = false
                throw e
            } catch (e: Exception) {
                getString(R.string.load_failed, e.message ?: e.javaClass.simpleName)
            }
            debugOutput.text = text
            debugButton.isEnabled = true
            PlaylistLoader.busy = false
        }
    }
}
