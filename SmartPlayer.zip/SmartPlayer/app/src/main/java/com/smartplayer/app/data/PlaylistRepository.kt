package com.smartplayer.app.data

import androidx.room.withTransaction
import com.smartplayer.app.parser.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class ImportResult(val channels: Int, val notModified: Boolean)

class PlaylistRepository(
    private val db: SmartDatabase,
    private val cacheDir: File
) {
    private val playlistDao = db.playlistDao()
    private val channelDao = db.channelDao()

    fun observePlaylists() = playlistDao.observeAll()

    suspend fun addPlaylist(name: String, url: String): Long =
        playlistDao.insert(PlaylistEntity(name = name.trim(), url = url.trim()))

    suspend fun renamePlaylist(playlist: PlaylistEntity, name: String, url: String) =
        playlistDao.update(playlist.copy(name = name.trim(), url = url.trim(), etag = null))

    /** Channels are removed automatically through the foreign key cascade. */
    suspend fun deletePlaylist(playlist: PlaylistEntity) = playlistDao.delete(playlist)

    /**
     * Downloads the playlist to a temp file first, then replaces the stored
     * channels in one transaction. The old list stays intact if the download
     * or parsing fails.
     */
    suspend fun refresh(playlist: PlaylistEntity, force: Boolean = false): ImportResult =
        withContext(Dispatchers.IO) {
            val conn = URL(playlist.url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (!force && playlist.etag != null) {
                conn.setRequestProperty("If-None-Match", playlist.etag)
            }
            try {
                val code = conn.responseCode
                when {
                    code == 304 -> ImportResult(playlist.channelCount, notModified = true)
                    code in 200..299 -> {
                        val tmp = File.createTempFile("playlist", ".m3u", cacheDir)
                        try {
                            conn.inputStream.use { input ->
                                tmp.outputStream().use { out -> input.copyTo(out) }
                            }
                            val count = importFile(playlist.id, tmp)
                            playlistDao.update(
                                playlist.copy(
                                    etag = conn.getHeaderField("ETag"),
                                    lastUpdated = System.currentTimeMillis(),
                                    channelCount = count
                                )
                            )
                            ImportResult(count, notModified = false)
                        } finally {
                            tmp.delete()
                        }
                    }
                    else -> throw IOException("HTTP $code")
                }
            } finally {
                conn.disconnect()
            }
        }

    /** Parses a local M3U file into the database. Used by [refresh] and tests. */
    suspend fun importFile(playlistId: Long, file: File): Int =
        withContext(Dispatchers.IO) {
            db.withTransaction {
                channelDao.deleteByPlaylist(playlistId)
                file.bufferedReader().use { reader ->
                    M3uParser.parse(reader, batchSize = 5000) { batch ->
                        channelDao.insertAll(
                            batch.map {
                                ChannelEntity(
                                    playlistId = playlistId,
                                    name = it.name,
                                    groupTitle = it.groupTitle,
                                    logoUrl = it.logoUrl,
                                    tvgId = it.tvgId,
                                    url = it.url
                                )
                            }
                        )
                    }
                }
            }
        }
}
