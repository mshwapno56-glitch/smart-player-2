package com.smartplayer.app

import com.smartplayer.app.data.ChannelDao
import com.smartplayer.app.data.ChannelEntity
import com.smartplayer.app.data.ChannelStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

/**
 * Checks whether channels answer, a few at a time, and saves the result.
 *
 * - [request] is called for rows that are on screen; [cancel] when a row leaves the screen
 *   before its turn. The most recently requested channel is checked first, so what the
 *   user is looking at right now is checked before rows already scrolled past.
 * - A channel counts as online when its link answers with a normal reply and sends data
 *   within a few seconds. Timeouts, refused connections, errors and HTML error pages
 *   count as offline.
 * - Results are written to the database in batches (about once a second) so the
 *   visible list refreshes calmly instead of after every single channel.
 *
 * The result only means "reachable from this phone's network right now". It does not
 * prove the picture is good. BDIX links, for example, only answer on Bangladeshi ISPs.
 */
class ChannelChecker(private val dao: ChannelDao, scope: CoroutineScope) {

    companion object {
        private const val WORKERS = 12
        private const val CONNECT_TIMEOUT_MS = 3_000
        private const val READ_TIMEOUT_MS = 4_000
        private const val MAX_REDIRECTS = 4
        private const val FLUSH_DELAY_MS = 1_200L
        private const val WRITE_BATCH = 500
    }

    private val lock = Any()
    private val queue = ArrayDeque<Long>()
    private val urls = HashMap<Long, String>()

    /** Ids queued, running or finished in this session; stops a row being checked twice. */
    private val requested = HashSet<Long>()

    private val wake = Channel<Unit>(Channel.UNLIMITED)
    private val results = Channel<Pair<Long, Boolean>>(Channel.UNLIMITED)

    init {
        repeat(WORKERS) { scope.launch(Dispatchers.IO) { worker() } }
        scope.launch(Dispatchers.IO) { writer() }
    }

    /** Queues [channel] if it has not been checked yet. Safe to call again and again. */
    fun request(channel: ChannelEntity) {
        if (channel.status != ChannelStatus.UNKNOWN) return
        val added = synchronized(lock) {
            if (requested.add(channel.id)) {
                queue.addLast(channel.id)
                urls[channel.id] = channel.url
                true
            } else {
                false
            }
        }
        if (added) wake.trySend(Unit)
    }

    /** Drops a channel that is still waiting. A check that already started is left to finish. */
    fun cancel(channelId: Long) {
        synchronized(lock) {
            if (queue.remove(channelId)) {
                urls.remove(channelId)
                requested.remove(channelId)
            }
        }
    }

    /** Forgets everything, used before all saved results are cleared. */
    fun reset() {
        synchronized(lock) {
            queue.clear()
            urls.clear()
            requested.clear()
        }
    }

    private fun popLatest(): Pair<Long, String>? = synchronized(lock) {
        val id = queue.removeLastOrNull()
        val url = if (id != null) urls.remove(id) else null
        if (id != null && url != null) id to url else null
    }

    private suspend fun worker() {
        for (ignored in wake) {
            val (id, url) = popLatest() ?: continue
            results.trySend(id to probe(url))
        }
    }

    private suspend fun writer() {
        while (true) {
            val first = results.receive()
            delay(FLUSH_DELAY_MS) // let more results gather before touching the database

            val online = ArrayList<Long>()
            val offline = ArrayList<Long>()
            var next: Pair<Long, Boolean>? = first
            while (next != null) {
                if (next.second) online.add(next.first) else offline.add(next.first)
                next = results.tryReceive().getOrNull()
            }

            try {
                val now = System.currentTimeMillis()
                online.chunked(WRITE_BATCH).forEach { dao.setStatus(it, ChannelStatus.ONLINE, now) }
                offline.chunked(WRITE_BATCH).forEach { dao.setStatus(it, ChannelStatus.OFFLINE, now) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // A failed save only means these channels get checked again later.
            }
        }
    }

    /** True when [startUrl] answers normally and starts sending data. Blocking. */
    private fun probe(startUrl: String): Boolean {
        var url = startUrl
        repeat(MAX_REDIRECTS + 1) {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = CONNECT_TIMEOUT_MS
                conn.readTimeout = READ_TIMEOUT_MS
                // Followed by hand: the built-in redirect handling refuses http -> https.
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("User-Agent", AppInfo.USER_AGENT)

                val code = conn.responseCode
                when (code) {
                    HttpURLConnection.HTTP_MOVED_PERM,
                    HttpURLConnection.HTTP_MOVED_TEMP,
                    HttpURLConnection.HTTP_SEE_OTHER,
                    307, 308 -> {
                        val location = conn.getHeaderField("Location") ?: return false
                        url = URL(URL(url), location).toString()
                    }
                    in 200..299 -> {
                        val type = conn.contentType.orEmpty().lowercase()
                        if (type.startsWith("text/html")) return false

                        // One read is enough: a live stream sends data right away.
                        val buffer = ByteArray(1024)
                        val read = conn.inputStream.read(buffer)
                        if (read <= 0) return false
                        // Some servers answer 200 with an HTML error page.
                        return buffer[0] != '<'.code.toByte()
                    }
                    else -> return false
                }
            } catch (e: Exception) {
                return false
            } finally {
                // disconnect() instead of closing the stream: a live stream never ends,
                // and closing it politely would wait for the rest of it.
                conn?.disconnect()
            }
            Unit // a redirect was followed: go round again with the new address
        }
        return false
    }
}
