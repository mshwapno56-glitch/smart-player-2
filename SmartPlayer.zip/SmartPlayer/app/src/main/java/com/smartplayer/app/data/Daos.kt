package com.smartplayer.app.data

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Insert
    suspend fun insert(playlist: PlaylistEntity): Long

    @Update
    suspend fun update(playlist: PlaylistEntity)

    @Delete
    suspend fun delete(playlist: PlaylistEntity)

    @Query("SELECT * FROM playlists ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :id")
    suspend fun getById(id: Long): PlaylistEntity?

    /** The playlist added most recently, or null when there are none. */
    @Query("SELECT * FROM playlists ORDER BY addedAt DESC, id DESC LIMIT 1")
    suspend fun newest(): PlaylistEntity?
}

@Dao
interface ChannelDao {
    @Insert
    suspend fun insertAll(channels: List<ChannelEntity>)

    @Query("DELETE FROM channels WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: Long)

    @Query("SELECT COUNT(*) FROM channels WHERE playlistId = :playlistId")
    suspend fun count(playlistId: Long): Int

    /**
     * One page-able query for the channel list. An empty [groupFilter] or [searchText]
     * means "no filter". Pages are loaded on demand, so 20,000+ channels never
     * sit in memory at once. [showOffline] = 0 hides channels found offline.
     */
    @Query(
        "SELECT * FROM channels WHERE playlistId = :playlistId " +
            "AND (:showOffline = 1 OR status != 2) " +
            "AND (:groupFilter = '' OR groupTitle = :groupFilter) " +
            "AND (:searchText = '' OR name LIKE '%' || :searchText || '%') " +
            "ORDER BY id"
    )
    fun pagingSource(
        playlistId: Long,
        groupFilter: String,
        searchText: String,
        showOffline: Int
    ): PagingSource<Int, ChannelEntity>

    /** Saves check results for a batch of channels. Keep batches under ~900 ids. */
    @Query("UPDATE channels SET status = :status, checkedAt = :checkedAt WHERE id IN (:ids)")
    suspend fun setStatus(ids: List<Long>, status: Int, checkedAt: Long)

    @Query("UPDATE channels SET status = 0, checkedAt = 0 WHERE playlistId = :playlistId")
    suspend fun resetStatus(playlistId: Long)

    @Query("SELECT COUNT(*) FROM channels WHERE playlistId = :playlistId AND status = :status")
    fun observeStatusCount(playlistId: Long, status: Int): Flow<Int>

    @Query("SELECT DISTINCT groupTitle FROM channels WHERE playlistId = :playlistId ORDER BY groupTitle")
    suspend fun groups(playlistId: Long): List<String>

    @Query("SELECT * FROM channels WHERE id = :id")
    suspend fun getChannel(id: Long): ChannelEntity?

    /** Next channel in the same order and filters as the channel list; skips offline ones. */
    @Query(
        "SELECT * FROM channels WHERE playlistId = :playlistId AND id > :afterId " +
            "AND status != 2 " +
            "AND (:groupFilter = '' OR groupTitle = :groupFilter) " +
            "AND (:searchText = '' OR name LIKE '%' || :searchText || '%') " +
            "ORDER BY id LIMIT 1"
    )
    suspend fun nextChannel(
        playlistId: Long,
        afterId: Long,
        groupFilter: String,
        searchText: String
    ): ChannelEntity?

    @Query(
        "SELECT * FROM channels WHERE playlistId = :playlistId AND id < :beforeId " +
            "AND status != 2 " +
            "AND (:groupFilter = '' OR groupTitle = :groupFilter) " +
            "AND (:searchText = '' OR name LIKE '%' || :searchText || '%') " +
            "ORDER BY id DESC LIMIT 1"
    )
    suspend fun previousChannel(
        playlistId: Long,
        beforeId: Long,
        groupFilter: String,
        searchText: String
    ): ChannelEntity?
}
