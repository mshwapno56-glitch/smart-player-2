package com.smartplayer.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.paging.LoadState
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load
import com.smartplayer.app.data.ChannelEntity
import com.smartplayer.app.data.ChannelStatus
import com.smartplayer.app.data.PlaylistEntity
import com.smartplayer.app.data.PlaylistRepository
import com.smartplayer.app.data.SmartDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

private val CHANNEL_DIFF = object : DiffUtil.ItemCallback<ChannelEntity>() {
    override fun areItemsTheSame(oldItem: ChannelEntity, newItem: ChannelEntity) =
        oldItem.id == newItem.id

    override fun areContentsTheSame(oldItem: ChannelEntity, newItem: ChannelEntity) =
        oldItem == newItem
}

private class ChannelViewHolder(
    val row: LinearLayout,
    val logo: ImageView,
    val name: TextView,
    val group: TextView
) : RecyclerView.ViewHolder(row) {
    /** The channel this row currently shows; used to start and stop its online check. */
    var channel: ChannelEntity? = null
}

/**
 * The home screen: the channels of the current playlist, straight away. Tapping a channel
 * opens the small floating video ([PlayerHost]). Playlists are managed in
 * Settings > Playlists; there is no playlist switcher here.
 */
class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: SmartDatabase
    private lateinit var repo: PlaylistRepository
    private lateinit var adapter: ChannelAdapter
    private lateinit var checker: ChannelChecker
    private lateinit var player: PlayerHost

    private lateinit var titleText: TextView
    private lateinit var searchInput: EditText
    private lateinit var groupButton: Button
    private lateinit var statusLine: TextView
    private lateinit var offlineButton: Button
    private lateinit var emptyText: TextView
    private lateinit var listControls: LinearLayout
    private lateinit var noPlaylistBox: LinearLayout
    private lateinit var list: RecyclerView

    private var createdLanguage = ""
    private var playlistId = -1L
    private var group = ""
    private var query = ""
    private var showOffline = false
    private var pagingJob: Job? = null
    private var statusJob: Job? = null

    private val searchTask = Runnable {
        query = searchInput.text.toString().trim()
        reload()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createdLanguage = AppPrefs.language(this)
        db = SmartDatabase.get(applicationContext)
        repo = PlaylistRepository(db, cacheDir)
        adapter = ChannelAdapter()
        checker = ChannelChecker(db.channelDao(), scope)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(28), dp(12), dp(8))
        }

        // Title row: current playlist name + Settings.
        titleText = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 20f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val settingsButton = Button(this).apply {
            text = getString(R.string.settings)
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(settingsButton)
        })

        // Shown instead of the channel list when there is no playlist at all.
        noPlaylistBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(48), dp(16), dp(16))
            visibility = View.GONE
            addView(TextView(context).apply {
                text = getString(R.string.no_playlist)
                textSize = 18f
                gravity = Gravity.CENTER
            })
            addView(Button(context).apply {
                text = getString(R.string.add_playlist)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, PlaylistsActivity::class.java))
                }
            })
        }
        content.addView(noPlaylistBox)

        listControls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        searchInput = EditText(this).apply {
            hint = getString(R.string.search_hint)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            doAfterTextChanged {
                // Wait until typing pauses, then search.
                handler.removeCallbacks(searchTask)
                handler.postDelayed(searchTask, 300)
                if (::player.isInitialized) player.onUserActivity()
            }
        }
        listControls.addView(searchInput)

        groupButton = Button(this).apply {
            text = getString(R.string.all_groups)
            setOnClickListener { showGroupDialog() }
        }
        listControls.addView(groupButton)

        statusLine = TextView(this).apply {
            textSize = 12f
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        listControls.addView(statusLine)

        offlineButton = Button(this).apply {
            text = getString(R.string.show_offline)
            textSize = 12f
            setOnClickListener {
                showOffline = !showOffline
                text = getString(if (showOffline) R.string.hide_offline else R.string.show_offline)
                reload()
            }
        }
        val recheckButton = Button(this).apply {
            text = getString(R.string.recheck)
            textSize = 12f
            setOnClickListener { confirmRecheck() }
        }
        val half = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        listControls.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(offlineButton, half)
            addView(recheckButton, LinearLayout.LayoutParams(half))
        })

        emptyText = TextView(this).apply {
            text = getString(R.string.no_results)
            setPadding(dp(8), dp(16), dp(8), dp(8))
            visibility = View.GONE
        }
        listControls.addView(emptyText)
        content.addView(listControls)

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            setHasFixedSize(true)
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                    // Scrolling the list starts the auto-fullscreen timer over.
                    if (::player.isInitialized) player.onUserActivity()
                }
            })
        }
        content.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val root = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)

        player = PlayerHost(this, root, scope, object : ChannelNavigator {
            override suspend fun neighbour(current: ChannelEntity, forward: Boolean): ChannelEntity? {
                val dao = db.channelDao()
                return if (forward) {
                    dao.nextChannel(current.playlistId, current.id, group, query)
                } else {
                    dao.previousChannel(current.playlistId, current.id, group, query)
                }
            }
        })

        adapter.addLoadStateListener { states ->
            val empty = states.refresh is LoadState.NotLoading && adapter.itemCount == 0
            emptyText.visibility = if (empty) View.VISIBLE else View.GONE
        }
    }

    override fun onStart() {
        super.onStart()
        if (AppPrefs.language(this) != createdLanguage) {
            // Language was changed in Settings.
            recreate()
            return
        }
        syncPlaylist()
        player.onStart()
    }

    override fun onStop() {
        super.onStop()
        player.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(searchTask)
        if (::player.isInitialized) player.onDestroy()
        scope.cancel()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    // ---- input: timer reset, back, keys ----

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_MOVE) {
            player.onUserActivity()
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        player.onUserActivity()
        if (player.handleKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!player.handleBack()) {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        player.onWindowFocusChanged(hasFocus)
    }

    // ---- current playlist ----

    /**
     * Shows the channels of the current playlist. When none is chosen (or it was deleted),
     * the most recently added playlist is used.
     */
    private fun syncPlaylist() {
        scope.launch {
            val savedId = AppPrefs.currentPlaylistId(this@MainActivity)
            var playlist = if (savedId >= 0) repo.getPlaylist(savedId) else null
            if (playlist == null) {
                playlist = repo.newestPlaylist()
                AppPrefs.setCurrentPlaylistId(this@MainActivity, playlist?.id ?: -1L)
            }
            applyPlaylist(playlist)
        }
    }

    private fun applyPlaylist(playlist: PlaylistEntity?) {
        val newId = playlist?.id ?: -1L
        titleText.text = playlist?.name ?: getString(R.string.app_name)
        if (newId == playlistId) return // same playlist: keep list position and video

        playlistId = newId
        player.closePlayer()
        group = ""
        query = ""
        showOffline = false
        offlineButton.text = getString(R.string.show_offline)
        groupButton.text = getString(R.string.all_groups)
        handler.removeCallbacks(searchTask)
        searchInput.setText("")

        val has = newId >= 0
        noPlaylistBox.visibility = if (has) View.GONE else View.VISIBLE
        listControls.visibility = if (has) View.VISIBLE else View.GONE
        list.visibility = if (has) View.VISIBLE else View.GONE

        statusJob?.cancel()
        pagingJob?.cancel()
        if (!has) {
            statusLine.text = ""
            return
        }

        statusJob = scope.launch {
            val dao = db.channelDao()
            combine(
                dao.observeStatusCount(newId, ChannelStatus.ONLINE),
                dao.observeStatusCount(newId, ChannelStatus.OFFLINE)
            ) { online, offline -> online to offline }
                .collect { (online, offline) ->
                    statusLine.text = getString(R.string.check_status, online, offline)
                }
        }
        reload()
        list.scrollToPosition(0)
    }

    /** Starts a fresh page stream for the current search text, group and offline setting. */
    private fun reload() {
        if (playlistId < 0) return
        pagingJob?.cancel()
        val id = playlistId
        pagingJob = scope.launch {
            Pager(PagingConfig(pageSize = 60, enablePlaceholders = false)) {
                db.channelDao().pagingSource(id, group, query, if (showOffline) 1 else 0)
            }.flow.collectLatest { adapter.submitData(it) }
        }
    }

    // ---- dialogs ----

    private fun AlertDialog.Builder.showAsModal(): AlertDialog {
        player.setModalOpen(true)
        val dialog = create()
        dialog.setOnDismissListener { player.setModalOpen(false) }
        dialog.show()
        return dialog
    }

    /** Clears all saved results so every channel is checked again as it comes into view. */
    private fun confirmRecheck() {
        val id = playlistId
        AlertDialog.Builder(this)
            .setTitle(R.string.recheck)
            .setMessage(R.string.recheck_message)
            .setPositiveButton(R.string.recheck) { _, _ ->
                scope.launch {
                    checker.reset()
                    db.channelDao().resetStatus(id)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .showAsModal()
    }

    private fun showGroupDialog() {
        val id = playlistId
        scope.launch {
            val groups = db.channelDao().groups(id).filter { it.isNotEmpty() }
            val options = (listOf(getString(R.string.all_groups)) + groups).toTypedArray()
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.group_title)
                .setItems(options) { _, which ->
                    group = if (which == 0) "" else groups[which - 1]
                    groupButton.text = options[which]
                    reload()
                }
                .showAsModal()
        }
    }

    // ---- list ----

    private inner class ChannelAdapter :
        PagingDataAdapter<ChannelEntity, ChannelViewHolder>(CHANNEL_DIFF) {

        /** Second line: a green dot for channels confirmed online, then the group name. */
        private fun groupLine(channel: ChannelEntity): CharSequence {
            if (channel.status != ChannelStatus.ONLINE) return channel.groupTitle
            val line = SpannableStringBuilder("●")
            line.setSpan(
                ForegroundColorSpan(Color.parseColor("#2E7D32")),
                0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            if (channel.groupTitle.isNotEmpty()) line.append("  ").append(channel.groupTitle)
            return line
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
            val ctx = parent.context
            val logo = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            }
            val name = TextView(ctx).apply {
                textSize = 16f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val group = TextView(ctx).apply {
                textSize = 12f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val texts = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(name)
                addView(group)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { leftMargin = dp(12) }
            }
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true // lets a TV remote highlight and select rows
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                addView(logo)
                addView(texts)
            }
            val ripple = TypedValue()
            if (ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)) {
                row.setBackgroundResource(ripple.resourceId)
            }
            return ChannelViewHolder(row, logo, name, group)
        }

        override fun onViewAttachedToWindow(holder: ChannelViewHolder) {
            super.onViewAttachedToWindow(holder)
            // The row is on screen: check this channel if it has not been checked yet.
            holder.channel?.let { checker.request(it) }
        }

        override fun onViewDetachedFromWindow(holder: ChannelViewHolder) {
            super.onViewDetachedFromWindow(holder)
            // Scrolled away before its turn: no need to check it now.
            holder.channel?.let { checker.cancel(it.id) }
        }

        override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
            val channel = getItem(position) ?: return

            // The row may be reused for another channel after the list refreshes.
            val previous = holder.channel
            if (previous != null && previous.id != channel.id) checker.cancel(previous.id)
            holder.channel = channel
            if (holder.itemView.isAttachedToWindow) checker.request(channel)

            holder.name.text = channel.name
            holder.group.text = groupLine(channel)
            holder.group.visibility =
                if (holder.group.text.isEmpty()) View.GONE else View.VISIBLE
            // Offline channels only show up when the user chose to show them.
            holder.name.setTextColor(
                if (channel.status == ChannelStatus.OFFLINE) Color.parseColor("#C62828") else Color.BLACK
            )

            val logoUrl = channel.logoUrl
            if (logoUrl.isNullOrEmpty()) {
                holder.logo.dispose()
                holder.logo.setImageDrawable(null)
            } else {
                holder.logo.load(logoUrl)
            }

            // Tap: play in the small floating video (or switch the running video).
            holder.row.setOnClickListener { player.play(channel) }
        }
    }
}
