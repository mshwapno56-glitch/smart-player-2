package com.smartplayer.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.smartplayer.app.data.PlaylistRepository
import com.smartplayer.app.data.SmartDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Temporary screen for steps 1-2: runs a 100,000-channel import benchmark so
 * parser and database speed can be checked on a real phone. Replaced by the
 * real playlist screens in step 3.
 */
class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var output: TextView
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Smart Player"
            textSize = 24f
        })
        button = Button(this).apply { text = "Test: import 100,000 channels" }
        root.addView(button)
        output = TextView(this).apply {
            gravity = Gravity.START
            text = "Press the button to run the speed test."
        }
        root.addView(ScrollView(this).apply { addView(output) })
        setContentView(root)

        button.setOnClickListener { runBenchmark() }
    }

    private fun runBenchmark() {
        button.isEnabled = false
        output.text = "Running..."
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                val db = SmartDatabase.get(applicationContext)
                val repo = PlaylistRepository(db, cacheDir)

                val file = File(cacheDir, "bench.m3u")
                val genStart = System.nanoTime()
                file.bufferedWriter().use { w ->
                    w.write("#EXTM3U\n")
                    for (i in 1..100_000) {
                        w.write(
                            "#EXTINF:-1 tvg-id=\"ch$i\" tvg-logo=\"http://example.com/$i.png\" " +
                                "group-title=\"Group ${i % 50}\",Channel $i\n"
                        )
                        w.write("http://example.com/live/$i.m3u8\n")
                    }
                }
                val genMs = (System.nanoTime() - genStart) / 1_000_000

                val id = repo.addPlaylist("Benchmark", "http://example.com/bench.m3u")
                val importStart = System.nanoTime()
                val count = repo.importFile(id, file)
                val importMs = (System.nanoTime() - importStart) / 1_000_000

                val playlist = db.playlistDao().getById(id)
                if (playlist != null) repo.deletePlaylist(playlist)
                val left = db.channelDao().count(id)
                file.delete()

                "File generated in $genMs ms\n" +
                    "Imported $count channels in $importMs ms\n" +
                    "Channels left after deleting the playlist: $left (should be 0)"
            }
            output.text = result
            button.isEnabled = true
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Scope is tied to the activity's lifetime only for this temporary screen.
    }
}
