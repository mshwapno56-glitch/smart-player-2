package com.smartplayer.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

/** Settings: language, auto-fullscreen delay, and the way to the playlists. */
class SettingsActivity : Activity() {

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        box.addView(TextView(this).apply {
            text = getString(R.string.settings)
            textSize = 24f
        })

        // Playlists
        box.addView(Button(this).apply {
            text = getString(R.string.playlists)
            setOnClickListener { startActivity(Intent(this@SettingsActivity, PlaylistsActivity::class.java)) }
        })

        // Language: applied at once.
        box.addView(sectionTitle(getString(R.string.language)))
        val languages = listOf(
            "" to R.string.lang_system,
            "en" to R.string.lang_english,
            "bn" to R.string.lang_bangla
        )
        val currentLanguage = AppPrefs.language(this)
        val languageGroup = RadioGroup(this)
        languages.forEachIndexed { index, (code, label) ->
            languageGroup.addView(RadioButton(this).apply {
                id = 1000 + index
                text = getString(label)
                isChecked = code == currentLanguage
            })
        }
        languageGroup.setOnCheckedChangeListener { _, checkedId ->
            val code = languages.getOrNull(checkedId - 1000)?.first ?: return@setOnCheckedChangeListener
            if (code != AppPrefs.language(this)) {
                AppPrefs.setLanguage(this, code)
                recreate()
            }
        }
        box.addView(languageGroup)

        // Auto fullscreen delay: saved at once.
        box.addView(sectionTitle(getString(R.string.auto_fullscreen)))
        val currentSeconds = AppPrefs.autoFullscreenSeconds(this)
        val timerGroup = RadioGroup(this)
        AppPrefs.AUTO_FULLSCREEN_CHOICES.forEachIndexed { index, seconds ->
            timerGroup.addView(RadioButton(this).apply {
                id = 2000 + index
                text = if (seconds == 0) {
                    getString(R.string.auto_fullscreen_off)
                } else {
                    getString(R.string.seconds_count, seconds)
                }
                isChecked = seconds == currentSeconds
            })
        }
        timerGroup.setOnCheckedChangeListener { _, checkedId ->
            val seconds = AppPrefs.AUTO_FULLSCREEN_CHOICES.getOrNull(checkedId - 2000)
                ?: return@setOnCheckedChangeListener
            AppPrefs.setAutoFullscreenSeconds(this, seconds)
        }
        box.addView(timerGroup)

        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(0, dp(20), 0, dp(4))
    }
}
